# Dynamic webcam

Visualizzare un'immagine remota dinamicamente attraverso un iframe

## Setup webserver per test locali

Creare un webserver locale che punti a questa cartella come root.

Ad esempio se si ha python installato

```sh
python -m SimpleHTTPServer 8102
```

### Snippet per pagine web

Includendo questo codice in una qualunque pagina web sia locale che remota permetterà di embeddare la webcam, con dimensioni adatte, caricata come pagina web invece che come immagine.

```html
<div class="rir-embed" style="width:100%;" data-page="51os8"></div><script src="http://localhost:8102/embed.js"></script>
```

Visualizzare la pagina nel browser.

> Un'esempio di pagina è anche presente in questa cartella, dal nome `third.html`.

### Spiegazione

L'idea è che lato server invece di esporre direttamente le immagini sempre allo stesso indirizzo, vengano generate dinamicamente pagine simili alla `51os8.html` che conterranno, ogni volta che sarà stata caricata un nuovo frame della webcam, un `<img src="" />` con indirizzo diverso. Questo permetterà di nascondere l'indirizzo dinamico delle immagini e forzarne la visualizzazione tramite pagina html da embeddare.

La pagina web potrà contenere qualunque javascript o altro elemento.
In particolare per ora è stato incluso Google Analytics ed un link che se cliccato porterà a visitare il sito originario di rifugi in rete.