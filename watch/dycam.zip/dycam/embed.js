/*! iFrame Resizer (iframeSizer.min.js ) - v3.5.5 - 2016-06-16
 *  Desc: Force cross domain iframes to size to content.
 *  Requires: iframeResizer.contentWindow.min.js to be loaded into the target frame.
 *  Copyright: (c) 2016 David J. Bradshaw - dave@bradshaw.net
 *  License: MIT
 */

window.onload = function() {
    
  var rirHost = 'http://localhost:8102'

  var rirEmbeds = document.getElementsByClassName('rir-embed')

  for (var i = 0; i < rirEmbeds.length; i++) {
    var embed = rirEmbeds[i];
    var id = embed.getAttribute('data-page');
    var source = embed.getAttribute('data-source');
    var iframe = document.createElement('iframe');
    var frame_id = 'rir-embed-' + id
    iframe.id = frame_id
    iframe.style.border = "none";
    iframe.style.width = "100%";
    iframe.style.height = "100%";
    iframe.scrolling = "no";
    if (!source) {
      source = rirHost
    }
    iframe.src = source + '/' + id + ".html";
    
    var content = document.createElement('div');
    content.classList.add('rir-embed-content');
    content.appendChild(iframe);
    embed.appendChild(content);

    var sc = document.createElement("link");
    sc.setAttribute("href", source + "/embed.css");
    sc.setAttribute("type", "text/css");
    sc.setAttribute("rel", "stylesheet");
    document.head.appendChild(sc);
  }
};
